# Resource Open Animal Nutrition — Adequacy Interoperability Guide



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "openanimalnutrition.fhir.animalnutrition",
  "language" : "en",
  "url" : "https://openanimalnutrition.org/fhir/animal-nutrition/ImplementationGuide/openanimalnutrition.fhir.animalnutrition",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.4.642.40.1004"
  }],
  "version" : "0.1.0",
  "name" : "OpenAnimalNutrition",
  "title" : "Open Animal Nutrition — Adequacy Interoperability Guide",
  "status" : "draft",
  "date" : "2026-10-26T20:14:00+00:00",
  "publisher" : "DVM Consulting, Inc. (provisional steward)",
  "contact" : [{
    "name" : "DVM Consulting, Inc. (provisional steward)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://openanimalnutrition.org"
    }]
  }],
  "description" : "A FHIR Implementation Guide for representing and verifying the nutritional adequacy of an animal diet against published requirement standards (NRC, AAFCO, FEDIAF), expressed on a common mathematical basis. Species-agnostic by design; v0.1 binds canine and feline coverage. This guide models the adequacy VERDICT, not the means of producing a passing diet.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "packageId" : "openanimalnutrition.fhir.animalnutrition",
  "fhirVersion" : ["5.0.0"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r5",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7_fhir_uv_extensions_r5",
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r5",
    "version" : "5.3.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r5#1.3.0"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-adequacy-interpretation.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/adequacy-interpretation"
      },
      "name" : "Adequacy Interpretation",
      "description" : "Per-nutrient and overall interpretations of a diet's nutrient levels against the applied requirement standard. The rules for `deficient` and `excess` are stated, proposed and pending ratification, on the [Decile Basis and Band Computation](band-computation.html) page.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-adequacy-interpretation-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/adequacy-interpretation-vs"
      },
      "name" : "Adequacy Interpretation Value Set",
      "description" : "All codes in the Adequacy Interpretation code system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-ExampleRestrictedMaintenanceAdequacy.html"
      }],
      "reference" : {
        "reference" : "Observation/ExampleRestrictedMaintenanceAdequacy"
      },
      "name" : "Adult-maintenance adequacy under a 25% caloric restriction, canine, vs NRC",
      "description" : "A dog fed 25% less energy than it needs, checked against NRC's recommended allowances for adult dogs at maintenance, under the caloric-restriction rule proposed, pending ratification, on the [Decile Basis and Band Computation](band-computation.html) page. Calcium at 1.2 g/Mcal meets NRC's minimum of 1 g/Mcal, but the restriction raises the minimum to 4/3 g/Mcal (recorded as 1.3333333, at 7 decimal places), so calcium is deficient. The overall verdict shown is illustrative: how it follows from the per-nutrient results is an open point on that page.",
      "isExample" : true,
      "profile" : ["https://openanimalnutrition.org/fhir/animal-nutrition/StructureDefinition/animal-nutrient-adequacy"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-ExampleAdultMaintenanceAdequacy.html"
      }],
      "reference" : {
        "reference" : "Observation/ExampleAdultMaintenanceAdequacy"
      },
      "name" : "Adult-maintenance adequacy, canine, vs AAFCO",
      "description" : "Adequacy of a canine adult-maintenance diet against AAFCO, with one nutrient under an authoritative maximum (calcium) and one under a derived-provisional ceiling (potassium). The overall verdict shown is illustrative: how it follows from the per-nutrient results is an open point on the [Decile Basis and Band Computation](band-computation.html) page.",
      "isExample" : true,
      "profile" : ["https://openanimalnutrition.org/fhir/animal-nutrition/StructureDefinition/animal-nutrient-adequacy"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-animal-nutrient-adequacy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/animal-nutrient-adequacy"
      },
      "name" : "Animal Nutrient Adequacy Assessment",
      "description" : "The result of the agnostic, mathematical check of a diet's resolved nutrient\nprofile against a selected requirement standard (NRC / AAFCO / FEDIAF) for a\ngiven species and life stage.\n\nEach assessed nutrient is a component carrying the diet's level, the applicable\nmin/max requirement range, the common-basis decile expression, and a\nper-nutrient interpretation. The decile expression is computed as stated,\nproposed and pending ratification, on the\n[Decile Basis and Band Computation](band-computation.html) page. The top-level\ninterpretation is the overall complete-and-balanced verdict.\n\nRatio nutrients such as Ca:P are components like any other nutrient, with a\nunitless quantity (UCUM `1`). Non-linear ratio nutrients are excluded from the\ncomponent model by design.\n\nA component's interpretation is `excess` only when the value is above an\nauthoritative maximum, one set by a standards body for the animal and the use\nit is applied to (maxProvenance\n`authoritative`), and not below a minimum set by the applied standard,\nincluding one raised for a caloric restriction or by the AAFCO dry matter\nfactor (below). Above a conditional, template-set or derived-provisional\nmaximum, and not below the minimum, the interpretation stays `adequate`. The\nband is then `range-d10` (\"Highest (90% of Range or\nGreater)\"), which alone does not show that the maximum was exceeded:\nreferenceRange.high holds the maximum, and maxProvenance says what kind it is.\n\nWhere a caloric restriction, or the AAFCO dry matter factor for a food below\n4 kcal/g of dry matter, raises a minimum set by the applied standard,\nreferenceRange.low holds the raised minimum, and the band is computed from it.\nA value below it is `deficient`, even if it meets the minimum that applies\nwith no adjustment. A verdict checked under a caloric restriction above 0 records the\npercentage in `caloricRestriction`. This rule, the condition on `excess` above,\nand which minimums they cover are stated, proposed and pending ratification, on\nthe [Decile Basis and Band Computation](band-computation.html) page.\n\n`performer` is optional. When a veterinarian, nutritionist or clinic ran or\nreviewed the check, name them (Practitioner, PractitionerRole or Organization).\nThe organization that only operates the checking software is not the performer\nunless it also reviewed this verdict. Software cannot be the performer of an\nObservation in FHIR R5 (`performer` does not accept a Device). When software\ncomputed the verdict, record it in `device`: a Device whose `name` and\n`version` give the software's name and version, so a reader can tell which\nchecker, and which version of it, produced the verdict.\n\nSCOPE: this profile models the VERDICT. Ingredient selection, fortification,\nand rounding (i.e. how a passing diet is produced) are out of scope by design.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-animal-nutrient.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/animal-nutrient"
      },
      "name" : "Animal Nutrients (STUB)",
      "description" : "STUB. Populate from the canonical nutrient list; map to SNOMED-vet / LOINC where possible. Ratio nutrients (e.g. Ca:P) need explicit handling, and non-linear ratios are excluded from the component model by design (see the [Animal Nutrient Adequacy Assessment](StructureDefinition-animal-nutrient-adequacy.html) profile). Which ratios count as non-linear is an open point on the [Decile Basis and Band Computation](band-computation.html) page.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-animal-nutrient-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/animal-nutrient-vs"
      },
      "name" : "Animal Nutrients Value Set",
      "description" : "All codes in the Animal Nutrients code system (a stub in v0.1).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-animal-species.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/animal-species"
      },
      "name" : "Animal Species (STUB)",
      "description" : "STUB. v0.1 implemented coverage only. TODO: bind to an external species value set.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-animal-species-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/animal-species-vs"
      },
      "name" : "Animal Species Value Set",
      "description" : "All codes in the Animal Species code system (a stub in v0.1).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-applied-requirement-standard.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/applied-requirement-standard"
      },
      "name" : "Applied Requirement Standard",
      "description" : "Which published requirement standard the adequacy check was run against, by its edition's code when the edition is known (for example AAFCO-2026). A variable selection, never hardcoded into the check.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-caloric-restriction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/caloric-restriction"
      },
      "name" : "Caloric Restriction",
      "description" : "The intentional caloric restriction that the check was run under, as a\npercentage of the animal's energy need, in UCUM `%`: 25 means that the animal\nis fed 25% less energy than it needs. Most of the applied standard's per-Mcal\nminimums are then multiplied by 1 ÷ (1 − restriction ÷ 100) (under an AAFCO\nselection, together with any AAFCO dry matter factor), so a nutrient can be\n`deficient` although it meets the minimum that applies with no restriction.\nThe source template accepts 0 (none) or a number from 1 to 55. Present only\nfor a restriction above 0, and absent when none was entered (blank or 0 in the\ntemplate). An intake\nentered in place of the calculated energy requirement is not a restriction.\nNeither it nor the template's figure for how far it falls below that\nrequirement (cell N4 on the template's Standards tab) is recorded here. Which\nminimums are raised, and the rule that makes a value below them `deficient`,\nare stated, proposed and pending ratification, on the\n[Decile Basis and Band Computation](band-computation.html) page.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-ExampleCaninePatient.html"
      }],
      "reference" : {
        "reference" : "Patient/ExampleCaninePatient"
      },
      "name" : "Example canine patient",
      "description" : "A dog, with species carried by the R5 patient-animal extension.",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-ExampleAdequacyChecker.html"
      }],
      "reference" : {
        "reference" : "Device/ExampleAdequacyChecker"
      },
      "name" : "Example checking software",
      "description" : "A placeholder for the software that computed the verdict, with its name and version.",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-ExampleVeterinarian.html"
      }],
      "reference" : {
        "reference" : "Practitioner/ExampleVeterinarian"
      },
      "name" : "Example veterinarian",
      "description" : "A placeholder veterinarian who ran or reviewed the check.",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-nutrient-life-stage.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/nutrient-life-stage"
      },
      "name" : "Life Stage",
      "description" : "The life stage whose requirements were applied (e.g. growth, adult maintenance). A variable selection.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-life-stage.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/life-stage"
      },
      "name" : "Life Stages",
      "description" : "Life stages for which requirement standards set nutrient requirements.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-life-stage-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/life-stage-vs"
      },
      "name" : "Life Stages Value Set",
      "description" : "All codes in the Life Stages code system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-maximum-provenance.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/maximum-provenance"
      },
      "name" : "Maximum Provenance",
      "description" : "The kind of maximum a nutrient's range high is: AUTHORITATIVE (set by a standards body for the animal and the use it is applied\nto), CONDITIONAL (a standard's figure with a condition the check\ndoes not verify), TEMPLATE-SET (set or computed by the source template) or\nDERIVED-PROVISIONAL (computed by a disclosed rule from the minimum). Only a\nvalue above an authoritative maximum is `excess`. How the source template's\nmaximum types map to these codes is stated, proposed and pending ratification,\non the [Decile Basis and Band Computation](band-computation.html) page.\n\nDerived ceilings prioritize consistency and determinism, NOT toxicological\ncalibration, and are revisable by the governance body. This flag exists so a\nconsumer can see at a glance which ceilings are authoritative and which are\nnot.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-maximum-provenance-code.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/maximum-provenance-code"
      },
      "name" : "Maximum Provenance Codes",
      "description" : "The kind of maximum a nutrient's range high is, which decides whether a value above it can be `excess`: only an authoritative maximum can. How the source template's maximum types map to these codes is stated, proposed and pending ratification, under Maximum types on the [Decile Basis and Band Computation](band-computation.html) page.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-maximum-provenance-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/maximum-provenance-vs"
      },
      "name" : "Maximum Provenance Value Set",
      "description" : "All codes in the Maximum Provenance Codes code system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-nutrient-decile.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/nutrient-decile"
      },
      "name" : "Nutrient Decile (Common-Basis Expression)",
      "description" : "The diet's level for this nutrient on the common mathematical basis used to compare across standards, expressed as a band of the Dynamic Decile System: four bands below the minimum and ten deciles from the minimum to the range high. Where an entry gets a band, a value above the range high is in range-d10 (Highest) unless it is below the minimum. The decile basis and band computation are stated on the [Decile Basis and Band Computation](band-computation.html) page, proposed and pending ratification by the governance body.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nutrient-decile.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nutrient-decile"
      },
      "name" : "Nutrient Decile Bands",
      "description" : "The 14 bands of the Dynamic Decile System: four bands below the requirement minimum, as a share of the minimum, and ten deciles from the minimum to the range high. Where an entry gets a band, a value above the range high is in range-d10 unless it is below the minimum. The computation is stated, proposed and pending ratification, on the [Decile Basis and Band Computation](band-computation.html) page.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nutrient-decile-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nutrient-decile-vs"
      },
      "name" : "Nutrient Decile Bands Value Set",
      "description" : "All codes in the Nutrient Decile Bands code system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-oan-assessment-code.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/oan-assessment-code"
      },
      "name" : "OAN Assessment Codes",
      "description" : "Codes for the kind of assessment an Open Animal Nutrition observation records.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-requirement-standard.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/requirement-standard"
      },
      "name" : "Requirement Standards",
      "description" : "Published nutrient requirement standards an adequacy check can be run against. Each standards body's code has a child code for each edition (is-a); record the edition's code when the edition is known. The editions are those the source template, Version 21OCT26b, cites.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-requirement-standard-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/requirement-standard-vs"
      },
      "name" : "Requirement Standards Value Set",
      "description" : "All codes in the Requirement Standards code system: the standards bodies and their editions.",
      "isExample" : false
    }],
    "page" : {
      "sourceUrl" : "toc.html",
      "name" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "sourceUrl" : "index.html",
        "name" : "index.html",
        "title" : "Open Animal Nutrition",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "band-computation.html",
        "name" : "band-computation.html",
        "title" : "Decile Basis and Band Computation (proposed, pending ratification)",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "known-limitations.html",
        "name" : "known-limitations.html",
        "title" : "Template Status and Known Limitations",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "copyrightyear"
      },
      "value" : "2026+"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "releaselabel"
      },
      "value" : "Pre-ratification draft"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "show-inherited-invariants"
      },
      "value" : "false"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "auto-oid-root"
      },
      "value" : "2.16.840.1.113883.4.642.40.1004"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "autoload-resources"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/capabilities"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/examples"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/extensions"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/models"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/operations"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/profiles"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/vocabulary"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/maps"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/testing"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/history"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "fsh-generated/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "template/config"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/assets"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/images"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid-template"
      },
      "value" : "template/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid-template"
      },
      "value" : "input/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-qa"
      },
      "value" : "temp/qa"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-temp"
      },
      "value" : "temp/pages"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-output"
      },
      "value" : "output"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-tx-cache"
      },
      "value" : "input-cache/txcache"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-suppressed-warnings"
      },
      "value" : "input/ignoreWarnings.txt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-history"
      },
      "value" : "https://openanimalnutrition.org/fhir/animal-nutrition/history.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-html"
      },
      "value" : "template-page.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-md"
      },
      "value" : "template-page-md.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-contact"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-context"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-copyright"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-jurisdiction"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-license"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-publisher"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-version"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-wg"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "active-tables"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "fmm-definition"
      },
      "value" : "http://hl7.org/fhir/versions.html#maturity"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "propagate-status"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludelogbinaryformat"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "tabbed-snapshots"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "i18n-default-lang"
      },
      "value" : "en"
    }]
  }
}

```
